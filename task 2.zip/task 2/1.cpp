#include <iostream>
using namespace std;

int main()
{
    // Declare an array of size n
    int n;
    cout << "Enter the size of the array: ";
    cin >> n;
    int arr[n];

    // Input the elements of the array
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    // Input the index to delete
    int index;
    cout << "Enter the index to delete (0 to " << n-1 << "): ";
    cin >> index;

    // Check if the index is valid
    if (index < 0 || index >= n)
    {
        cout << "Invalid index" << endl;
        return 0;
    }

    // Shift the elements to the left from the index
    for (int i = index; i < n-1; i++)
    {
        arr[i] = arr[i+1];
    }

    // Decrease the size of the array by 1
    n--;

    // Print the updated array
    cout << "The updated array is: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
